﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace almacenamientoDeDatos
{
    public partial class frmPrincipal : Form
    {
    
        /// <summary>
        ///  Santiago Cano Florez 
        ///  15/04/2023
        ///  Implementar y poder trabajar con datos (TXT,CSV,XML,RTF)
        /// </summary>
        public frmPrincipal()
        {
            InitializeComponent();
        }
        
        //Mostramos con el boton TXT
        private void btnTxt_Click(object sender, EventArgs e)
        {
            frmTxt txt = new frmTxt("personas.txt");

            Hide();
            txt.Show();

        }

        //Mostramos con el boton CSV
        private void btnCsv_Click(object sender, EventArgs e)
        {
            frmCsv csv = new frmCsv();

            Hide();
            csv.Show();
        }

        //Mostramos con el boton XML
        private void btnXml_Click(object sender, EventArgs e)
        {
            frmXml xml = new frmXml();

            Hide();
            xml.Show();
        }
        //Mostramos con el boton RTF
        private void btnRtf_Click(object sender, EventArgs e)
        {
            frmRtf rtf = new frmRtf();

            Hide();
            rtf.Show();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
