﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace almacenamientoDeDatos
{

    // mostrar y manipular datos de personas y almacenarlos en una lista y mostrarlos en el formulario
    public partial class frmCsv : Form
    {
        public List<Persona> personas = new List<Persona>();

        public frmCsv()
        {
            InitializeComponent();

            

            leerArchivo();
            llenarArchivo();

            dgvPersonas.DataSource = personas;

            dgvPersonas.Columns["id"].HeaderText = "ID";
            dgvPersonas.Columns["name"].HeaderText = "Nombre";
        }


        // Escribimos los datos en un archivo CSV con la ubicacion especifica
        public void llenarArchivo()
        {

            StreamWriter sw = new StreamWriter("..\\..\\utils\\personas.csv");

            foreach (Persona p in personas)
            {
                sw.WriteLine($"{p.id},{p.name}");

            }
            sw.Close();
        }

        public void leerArchivo()
        {
            StreamReader sr = new StreamReader("..\\..\\utils\\personas.csv");
            string linea;
            bool idRepetido = false;
            linea = sr.ReadLine();

            while (linea != null)
            {
                string[] vec = linea.Split(',');
                try
                {

                    foreach (Persona p in personas)
                    {
                        if (p.id == Convert.ToInt32(vec[0]))
                        {
                            idRepetido = true;
                        }
                    }

                    if (idRepetido == false)
                    {
                        personas.Add(new Persona(Convert.ToInt32(vec[0]), vec[1]));
                    }



                }
                catch (Exception e)
                {
                    Console.WriteLine("Ha ocurrido un error inesperado " + e);
                }

                linea = sr.ReadLine();
            }
            sr.Close();
        }


        //Poder leer el archivo CSV de la ubicacion especifica y verificar ids 
        private void imgAtras_Click(object sender, EventArgs e)
        {
            frmPrincipal inicio = new frmPrincipal();
            Hide();
            inicio.Show();
        }

        private void frmCsv_Load(object sender, EventArgs e)
        {

        }


        //Poder tener un Ids unico y guardar los cambios y/o actualizados y mostrar error si no hay campos
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Random n = new Random();
            int id = 0;
            bool idRepetido = false;


            if (txtAgregar.Text.Trim() != "")
            {
                do
                {
                    id = n.Next(1000000, 9999999);

                    if (personas.Count > 0)
                    {
                        foreach (Persona p in personas)
                        {
                            if (id == p.id)
                            {
                                idRepetido = true;
                                break;
                            }
                        }
                    }

                } while (idRepetido == true);


                personas.Add(new Persona(id, txtAgregar.Text));
                llenarArchivo();
                MessageBox.Show("Se ha creado el usuario correctamente");
                txtAgregar.Clear();
            }
            else
            {
                MessageBox.Show("Se debe ingresar el nombre");
            }

            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = personas;
        }


        //Permitimos crear el nombre del objeto persona en la lista
        private void btnEditar_Click_1(object sender, EventArgs e)
        {
            bool idEncontrado = false;
            int id = 0;

            if (txtNueID.Text.Trim() == "" || txtNueNombre.Text.Trim() == "")
            {
                MessageBox.Show("Digite ID y su nuevo nombre");
                return;
            }


            foreach (Persona p in personas)
            {

                if (int.TryParse(txtNueID.Text.Trim(), out id) && id == p.id)
                {

                    idEncontrado = true;
                    p.name = txtNueNombre.Text;
                    txtNueNombre.Clear();
                    txtNueID.Clear();

                    MessageBox.Show("El nombre ");
                }

            }


            if (idEncontrado == false)
            {
                MessageBox.Show("Ingrese el id valido");
            }

            llenarArchivo();

            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = personas;
        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            bool eliminado = false;
            int id = 0;


            foreach (Persona p in personas)
            {

                if (int.TryParse(txtEliminar.Text.Trim(), out id) && id == p.id)
                {

                    eliminado = true;
                    personas.Remove(p);
                    MessageBox.Show("Se han eliminado los datos correctamente");
                    txtEliminar.Clear();
                    llenarArchivo();
                    break;
                }

            }

            if (eliminado == false)
            {
                MessageBox.Show("No han sido eliminados los datos del usuario");
            }

            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = personas;
        }
    }
}
